<html>
<title>School Fee Portal</title>
<head>
	<!-- <script type="text/javascript" src="add_Student.js"></script> -->
	</head>
<body>
	<form action="STUDENT_DETAIL.php" method="get">
<div id="student_detail">
	<!-- <script type="text/javascript" src="add_Student.js"></script> -->
<fieldset>
	<legend>GET STUDENT DETAIL</legend>

<tr>
<td>Admission No.</td>
<td><input type="text" name="admno" id="admno" size="30"></td>
</tr>
<input type = "submit" name = "login" value = "GET STUDENT DETAIL"/>
</fieldset>
</div>
</form>
</body>
</html>

