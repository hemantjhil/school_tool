<html>
<title>SCHOOL TRANSFER CERTIFICATE</title>
<head>
	<!-- <script type="text/javascript" src="add_Student.js"></script> -->
	</head>
<body>
	<form action="GENERATE_TRANSFER_CERTIFICATE.php" method="get">
<div id="student_detail">
	<!-- <script type="text/javascript" src="add_Student.js"></script> -->
<fieldset>
<center>
	<legend>FILL STUDENT DETAIL</legend>

<tr>
<td>Admission No.</td>
<td><input type="text" name="admno" id="admno" size="30"></td>
<td>TC No.</td>
<td><input type="text" name="tcno" id="tcno" size="30"></td>
</tr>

<input type = "submit" name = "login" value = "GENERATE TRANSFER CERTIFICATE"/>
</center>
</fieldset>
</div>
</form>
</body>
</html>

